package com.uwu.study.db.shardingspheredemo.server;

public interface UserService {
    void createUser();

}
