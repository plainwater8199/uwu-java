package com.uwu.study.db.shardingspheredemo.entity;

import lombok.Data;

@Data
public class Statistic {
    private Long id;
    private Long customerId;
    private String data;
}
