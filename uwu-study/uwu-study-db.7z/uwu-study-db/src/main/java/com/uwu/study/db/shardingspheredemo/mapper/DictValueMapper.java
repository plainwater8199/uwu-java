package com.uwu.study.db.shardingspheredemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.uwu.study.db.shardingspheredemo.entity.DictValue;

public interface DictValueMapper extends BaseMapper<DictValue> {
}
